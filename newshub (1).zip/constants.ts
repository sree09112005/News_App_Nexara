
export const CATEGORIES = [
  { id: 'general', label: 'Top Stories' },
  { id: 'technology', label: 'Technology' },
  { id: 'business', label: 'Business' },
  { id: 'sports', label: 'Sports' },
  { id: 'entertainment', label: 'Entertainment' },
  { id: 'politics', label: 'Politics' },
  { id: 'science', label: 'Science' },
  { id: 'health', label: 'Health' },
  { id: 'space', label: 'Space' },
  { id: 'environment', label: 'Environment' },
  { id: 'travel', label: 'Travel' },
  { id: 'food', label: 'Food' },
];

export const LANGUAGES = [
  { code: 'en', label: 'English' },
  { code: 'hi', label: 'Hindi (हिंदी)' },
  { code: 'bn', label: 'Bengali (বাংলা)' },
  { code: 'te', label: 'Telugu (తెలుగు)' },
  { code: 'mr', label: 'Marathi (मराठी)' },
  { code: 'ta', label: 'Tamil (தமிழ்)' },
  { code: 'gu', label: 'Gujarati (ગુજરાતી)' },
  { code: 'kn', label: 'Kannada (కನ್ನಡ)' },
  { code: 'ml', label: 'Malayalam (മലയാളం)' },
  { code: 'pa', label: 'Punjabi (पंजबी)' },
  { code: 'es', label: 'Spanish (Español)' },
  { code: 'fr', label: 'French (Français)' },
  { code: 'de', label: 'German (Deutsch)' },
  { code: 'zh', label: 'Chinese (中文)' },
];

export const MOCK_NEWS_DELAY = 800;

export const TRANSLATIONS: Record<string, any> = {
  en: {
    home: 'Home', search: 'Search', saved: 'Saved', settings: 'Settings',
    latestNews: 'Latest News', resultsFor: 'Results for', noResults: 'No results found',
    savedArticles: 'Saved Articles', noSaved: 'No saved articles yet',
    searchPlaceholder: 'Search topics, sources...', readFull: 'Read full story at',
    loading: 'Loading...', overview: 'Overview', keyTakeaways: 'Key Takeaways',
    generateSummary: 'Generate AI Summary', analyzing: 'Analyzing article...',
    imageSource: 'Image Source', webReferenced: 'Web Referenced', aiGenerated: 'AI Generated',
    imageStyle: 'AI Image Style', photorealistic: 'Photorealistic', illustrative: 'Illustrative', abstract: 'Abstract',
    relatedStories: 'Related Stories', minRead: 'min read'
  },
  hi: {
    home: 'होम', search: 'खोजें', saved: 'सहेजे गए', settings: 'सेटिंग्स',
    latestNews: 'ताज़ा ख़बरें', resultsFor: 'परिणाम', noResults: 'कोई परिणाम नहीं मिला',
    savedArticles: 'सहेजे गए लेख', noSaved: 'कोई लेख सहेजा नहीं गया',
    searchPlaceholder: 'विषय या स्रोत खोजें...', readFull: 'पूरी कहानी पढ़ें',
    loading: 'लोड हो रहा है...', अवलोकन: 'अवलोकन', keyTakeaways: 'मुख्य बिंदु',
    generateSummary: 'AI सारांश बनाएं', analyzing: 'विश्लेषण कर रहा है...',
    imageSource: 'छवि स्रोत', webReferenced: 'वेब संदर्भित', aiGenerated: 'AI जनित',
    imageStyle: 'AI छवि शैली', photorealistic: 'यथार्थवादी', illustrative: 'चित्रात्मक', abstract: 'अमूर्त',
    relatedStories: 'संबंधित खबरें', minRead: 'मिनट पढ़ें'
  }
};
