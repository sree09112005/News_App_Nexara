
import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { UserSettings, Article } from '../types';

interface AppContextType {
  settings: UserSettings;
  updateSettings: (newSettings: Partial<UserSettings>) => void;
  bookmarks: Article[];
  toggleBookmark: (article: Article) => void;
  isBookmarked: (articleId: string) => boolean;
}

const defaultSettings: UserSettings = {
  theme: 'light',
  language: 'en',
  notifications: true,
  dataSaver: false,
  imageSource: 'web',
  aiImageStyle: 'photorealistic',
};

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [settings, setSettings] = useState<UserSettings>(() => {
    const saved = localStorage.getItem('newshub-settings');
    if (saved) {
      const parsed = JSON.parse(saved);
      return { ...defaultSettings, ...parsed };
    }
    return defaultSettings;
  });

  const [bookmarks, setBookmarks] = useState<Article[]>(() => {
    const saved = localStorage.getItem('newshub-bookmarks');
    return saved ? JSON.parse(saved) : [];
  });

  useEffect(() => {
    localStorage.setItem('newshub-settings', JSON.stringify(settings));
    if (settings.theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [settings]);

  useEffect(() => {
    localStorage.setItem('newshub-bookmarks', JSON.stringify(bookmarks));
  }, [bookmarks]);

  const updateSettings = (newSettings: Partial<UserSettings>) => {
    setSettings(prev => ({ ...prev, ...newSettings }));
  };

  const toggleBookmark = (article: Article) => {
    setBookmarks(prev => {
      const exists = prev.find(b => b.id === article.id);
      if (exists) {
        return prev.filter(b => b.id !== article.id);
      } else {
        return [...prev, article];
      }
    });
  };

  const isBookmarked = (articleId: string) => {
    return bookmarks.some(b => b.id === articleId);
  };

  return (
    <AppContext.Provider value={{ settings, updateSettings, bookmarks, toggleBookmark, isBookmarked }}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error("useApp must be used within AppProvider");
  return context;
};
