
import React from 'react';
import { useApp } from '../context/AppContext';
import { NewsCard } from '../components/NewsCard';
import { Bookmark } from 'lucide-react';
import { TRANSLATIONS } from '../constants';

export const Bookmarks: React.FC = () => {
  const { bookmarks, settings } = useApp();
  const t = TRANSLATIONS[settings.language] || TRANSLATIONS['en'];

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-gray-900 dark:text-white">{t.savedArticles}</h1>
      
      {bookmarks.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-20 text-gray-400">
          <div className="bg-gray-100 dark:bg-gray-800 p-6 rounded-full mb-4">
            <Bookmark className="w-10 h-10" />
          </div>
          <p className="text-lg font-medium">{t.noSaved}</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
          {bookmarks.map((article) => (
            <NewsCard key={article.id} article={article} />
          ))}
        </div>
      )}
    </div>
  );
};
