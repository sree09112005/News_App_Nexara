
import React, { useEffect, useState, useMemo } from 'react';
import { useParams, useLocation, useNavigate } from 'react-router-dom';
import { Article, AIImageStyle } from '../types';
import { getArticleById, getRelatedArticles } from '../services/newsService';
import { AISummary } from '../components/AISummary';
import { NewsCard } from '../components/NewsCard';
import { ArrowLeft, Share2, Bookmark, Globe, ImageOff, Calendar, Clock, RefreshCcw, Sparkles } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { TRANSLATIONS } from '../constants';

const SafeImage: React.FC<{ 
  primarySrc: string | null; 
  fallbackSrc: string | null; 
  alt: string; 
  className: string;
  label?: string;
  isDecoration?: boolean;
}> = ({ primarySrc, fallbackSrc, alt, className, label, isDecoration = false }) => {
  const [currentSrc, setCurrentSrc] = useState<string | null>(primarySrc);
  const [status, setStatus] = useState<'loading' | 'primary' | 'fallback' | 'error'>('loading');

  useEffect(() => {
    if (primarySrc) {
      setCurrentSrc(primarySrc);
      setStatus('loading');
    } else if (fallbackSrc) {
      setCurrentSrc(fallbackSrc);
      setStatus('fallback');
    } else {
      setStatus('error');
    }
  }, [primarySrc, fallbackSrc]);

  const handleImgError = () => {
    if (status === 'loading' || status === 'primary') {
      if (fallbackSrc && currentSrc !== fallbackSrc) {
        setCurrentSrc(fallbackSrc);
        setStatus('fallback');
      } else {
        setStatus('error');
      }
    } else {
      setStatus('error');
    }
  };

  if (status === 'error' || !currentSrc) {
    if (isDecoration) {
      return <div className={`${className} bg-gradient-to-br from-gray-100 to-gray-200 dark:from-gray-800 dark:to-gray-900 rounded-[3rem] animate-pulse`} />;
    }
    return (
      <div className={`${className} bg-gray-50 dark:bg-gray-800/50 flex flex-col items-center justify-center border-2 border-dashed border-gray-200 dark:border-gray-700 rounded-[4rem]`}>
        <div className="bg-primary/5 p-6 rounded-full mb-4">
          <ImageOff className="w-10 h-10 text-primary opacity-20" />
        </div>
        <span className="text-[10px] font-black uppercase tracking-[0.5em] text-gray-400">Visual Missing</span>
      </div>
    );
  }

  return (
    <div className={`relative overflow-hidden ${className} group bg-gray-200 dark:bg-gray-800`}>
      {(status === 'loading') && (
        <div className="absolute inset-0 bg-gray-100 dark:bg-gray-800 animate-pulse flex items-center justify-center z-10">
          <RefreshCcw className="w-10 h-10 text-primary animate-spin opacity-20" />
        </div>
      )}
      <img 
        src={currentSrc} 
        alt={alt} 
        className={`w-full h-full object-cover transition-opacity duration-1000 group-hover:scale-105 ${status === 'loading' ? 'opacity-0' : 'opacity-100'}`}
        onLoad={() => setStatus(status === 'fallback' ? 'fallback' : 'primary')}
        onError={handleImgError}
      />
      
      {label && (
        <div className="absolute top-8 left-8 flex flex-col gap-2 z-20">
          <div className="bg-primary shadow-2xl text-white text-[10px] font-black uppercase px-6 py-2.5 rounded-2xl tracking-[0.2em] border border-white/20">
            {label}
          </div>
          {status === 'fallback' && (
            <div className="bg-black/50 backdrop-blur-xl px-5 py-2 rounded-2xl text-[9px] font-black text-white uppercase tracking-[0.3em] border border-white/10 flex items-center gap-2">
              <Sparkles className="w-3 h-3" />
              AI Rendering
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export const ArticleDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const location = useLocation();
  const navigate = useNavigate();
  const { isBookmarked, toggleBookmark, settings } = useApp();
  const t = TRANSLATIONS[settings.language] || TRANSLATIONS['en'];
  
  const [article, setArticle] = useState<Article | null>((location.state as any)?.article || null);
  const [loading, setLoading] = useState(!article);
  const [related, setRelated] = useState<Article[]>([]);

  useEffect(() => {
    window.scrollTo(0, 0);
    const loadContent = async () => {
      if (!article && id) {
        const data = await getArticleById(id);
        setArticle(data || null);
      }
      setLoading(false);
    };
    loadContent();
  }, [id, article]);

  useEffect(() => {
    if (article) {
      getRelatedArticles(article).then(setRelated);
    }
  }, [article]);

  const ContentImage = ({ context, index }: { context: string; index: number }) => {
    const webSrc = article?.additionalImageUrls?.[index] || null;
    const styleModifier = settings.aiImageStyle === 'photorealistic' ? 'professional photography' : 
                          settings.aiImageStyle === 'illustrative' ? 'modern illustration' : 'abstract art';
    
    const keywords = context.toLowerCase().replace(/[^a-z0-9\s]/gi, '').split(/\s+/).filter(w => w.length > 4).slice(0, 8).join(' ');
    const aiPrompt = `${styleModifier} ${keywords}`.substring(0, 150);
    const aiSrc = `https://image.pollinations.ai/prompt/${encodeURIComponent(aiPrompt)}?width=1280&height=720&nologo=true&seed=${index + 500}`;

    return (
      <div className="my-16">
        <div className="overflow-hidden rounded-[3.5rem] shadow-2xl border border-gray-100 dark:border-gray-800">
           <SafeImage 
              primarySrc={webSrc} 
              fallbackSrc={aiSrc} 
              alt="Story visual" 
              className="w-full aspect-[16/10]" 
              label={article?.source.name}
              isDecoration={true}
           />
        </div>
        <div className="flex items-center justify-center gap-6 mt-8">
          <div className="h-px bg-gray-100 dark:bg-gray-800 flex-grow"></div>
          <p className="text-[9px] uppercase font-black tracking-[0.5em] text-gray-400 opacity-60">
            {webSrc ? 'Source Media' : 'AI Illustration'}
          </p>
          <div className="h-px bg-gray-100 dark:bg-gray-800 flex-grow"></div>
        </div>
      </div>
    );
  };

  if (loading) return (
    <div className="p-32 text-center flex flex-col items-center">
      <RefreshCcw className="w-14 h-14 text-primary animate-spin mb-8" />
      <span className="font-black uppercase tracking-[0.5em] text-gray-400">{t.loading}</span>
    </div>
  );
  
  if (!article) return <div className="p-32 text-center font-black uppercase text-red-500 tracking-widest">Source Not Found</div>;

  const bookmarked = isBookmarked(article.id);
  const paragraphs = (article.content || article.description || '')
    .split('\n')
    .filter(p => p.trim().length > 20);

  const formattedDateTime = new Date(article.publishedAt).toLocaleString(undefined, {
    weekday: 'long',
    month: 'long',
    day: 'numeric',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });

  return (
    <div className="pb-40 animate-fadeIn">
      <article className="max-w-3xl mx-auto px-4">
        <div className="flex items-center justify-between mb-12 py-10">
          <button 
            onClick={() => navigate(-1)} 
            className="p-5 bg-white dark:bg-gray-800 rounded-[2rem] shadow-sm border border-gray-100 dark:border-gray-700 hover:scale-110 active:scale-95 transition-all"
          >
            <ArrowLeft className="w-6 h-6 text-gray-700 dark:text-gray-300" />
          </button>
          <div className="flex gap-4">
            <button 
              onClick={() => toggleBookmark(article!)} 
              className={`p-5 rounded-[2rem] shadow-sm transition-all border ${bookmarked ? 'bg-secondary text-white border-secondary' : 'bg-white dark:bg-gray-800 text-gray-500 border-gray-100 dark:border-gray-700'}`}
            >
              <Bookmark className={`w-6 h-6 ${bookmarked ? 'fill-current' : ''}`} />
            </button>
            <button className="p-5 bg-white dark:bg-gray-800 rounded-[2rem] shadow-sm border border-gray-100 dark:border-gray-700 text-gray-500">
              <Share2 className="w-6 h-6" />
            </button>
          </div>
        </div>

        <div className="mb-14 text-center">
          <h1 className="text-4xl md:text-6xl font-black text-gray-900 dark:text-white leading-[1.05] mb-12 tracking-tight">
            {article.title}
          </h1>
          <div className="flex flex-col md:flex-row items-center justify-center gap-6 text-gray-400 text-[10px] font-black uppercase tracking-[0.3em]">
            <span className="flex items-center gap-3"><Calendar className="w-4 h-4 text-primary" /> {formattedDateTime}</span>
            <span className="hidden md:block w-2 h-2 bg-primary/20 rounded-full"></span>
            <span className="flex items-center gap-3"><Clock className="w-4 h-4 text-primary" /> global intelligence</span>
          </div>
        </div>

        <div className="mb-16">
          <SafeImage 
            primarySrc={article.urlToImage} 
            fallbackSrc={article.aiImageUrl || null} 
            alt={article.title} 
            className="w-full aspect-[16/9] rounded-[4rem] shadow-[0_40px_80px_-15px_rgba(0,0,0,0.35)] dark:shadow-black/60" 
            label={article.source.name}
          />
        </div>

        <AISummary content={article.content || article.description || ''} title={article.title} />

        <div className="mt-20 prose dark:prose-invert max-w-none">
          <div className="text-gray-800 dark:text-gray-300 leading-[2.1] text-xl font-medium space-y-12">
            {paragraphs.length > 0 ? paragraphs.map((para, i) => (
              <React.Fragment key={i}>
                <p className={i === 0 ? "first-letter:text-9xl first-letter:font-black first-letter:text-primary first-letter:mr-6 first-letter:float-left first-letter:leading-[0.65] pt-2" : ""}>
                  {para}
                </p>
                
                {i === 0 && paragraphs.length > 1 && (
                  <ContentImage context={paragraphs[1]} index={0} />
                )}
                
                {i === 3 && paragraphs.length > 5 && (
                  <ContentImage context={para} index={1} />
                )}
              </React.Fragment>
            )) : (
               <div className="text-center py-24 opacity-20 italic font-black uppercase tracking-[0.6em]">Narrative Pending</div>
            )}
          </div>
        </div>

        <div className="mt-20 pt-16 border-t border-gray-100 dark:border-gray-800">
          <a 
            href={article.url} 
            target="_blank" 
            rel="noopener noreferrer" 
            className="flex items-center justify-between p-12 rounded-[3.5rem] bg-gradient-to-br from-primary to-blue-700 text-white font-black uppercase tracking-[0.25em] hover:scale-[1.03] active:scale-95 transition-all shadow-2xl shadow-primary/40 group"
          >
            <div className="flex items-center gap-6">
               <Globe className="w-8 h-8 group-hover:rotate-12 transition-transform" />
               <span>Read Full Story</span>
            </div>
            <RefreshCcw className="w-7 h-7 rotate-45 group-hover:rotate-90 transition-transform" />
          </a>
        </div>
      </article>

      {/* Related Content Section */}
      {related.length > 0 && (
        <section className="mt-32 border-t border-gray-100 dark:border-gray-800 pt-20 px-4 max-w-6xl mx-auto">
          <div className="flex items-center justify-between mb-12">
            <h2 className="text-3xl font-black text-gray-900 dark:text-white tracking-tight uppercase">
              {t.relatedStories}
            </h2>
            <div className="flex gap-2">
              <div className="w-10 h-1.5 bg-primary rounded-full"></div>
              <div className="w-4 h-1.5 bg-gray-200 dark:bg-gray-700 rounded-full"></div>
            </div>
          </div>
          
          <div className="flex gap-6 overflow-x-auto pb-8 scrollbar-hide -mx-4 px-4 snap-x">
            {related.map((article) => (
              <div key={article.id} className="snap-start">
                <NewsCard article={article} minimal />
              </div>
            ))}
          </div>
        </section>
      )}
    </div>
  );
};
