
import React, { useState } from 'react';
import { Search as SearchIcon, Loader2, X } from 'lucide-react';
import { searchNews } from '../services/newsService';
import { Article } from '../types';
import { NewsCard } from '../components/NewsCard';
import { useApp } from '../context/AppContext';
import { TRANSLATIONS } from '../constants';

export const Search: React.FC = () => {
  const { settings } = useApp();
  const t = TRANSLATIONS[settings.language] || TRANSLATIONS['en'];
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<Article[]>([]);
  const [loading, setLoading] = useState(false);
  const [hasSearched, setHasSearched] = useState(false);

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim()) return;
    
    setLoading(true);
    setHasSearched(true);
    try {
      const data = await searchNews(query, settings);
      setResults(data);
    } finally {
      setLoading(false);
    }
  };

  const clearSearch = () => {
    setQuery('');
    setResults([]);
    setHasSearched(false);
  };

  return (
    <div className="space-y-6">
      <form onSubmit={handleSearch} className="relative">
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder={t.searchPlaceholder}
          className="w-full pl-12 pr-10 py-4 bg-white dark:bg-gray-800 border-none rounded-2xl shadow-sm focus:ring-2 focus:ring-primary text-lg text-gray-900 dark:text-white"
        />
        <SearchIcon className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
        {query && (
          <button 
            type="button" 
            onClick={clearSearch}
            className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
          >
            <X className="w-5 h-5" />
          </button>
        )}
      </form>

      <div>
        {loading ? (
          <div className="flex flex-col items-center justify-center py-12 text-gray-500">
            <Loader2 className="w-8 h-8 animate-spin text-primary mb-2" />
            <p>{t.loading}</p>
          </div>
        ) : (
          <>
            {hasSearched && (
              <h2 className="text-xl font-bold mb-4 text-gray-800 dark:text-white">
                {results.length} {t.resultsFor} "{query}"
              </h2>
            )}
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              {results.map((article) => (
                <NewsCard key={article.id} article={article} />
              ))}
            </div>

            {hasSearched && results.length === 0 && (
              <div className="text-center py-12 text-gray-500">
                <p>{t.noResults}</p>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
};
