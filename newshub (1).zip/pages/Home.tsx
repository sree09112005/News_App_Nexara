
import React, { useEffect, useState } from 'react';
import { CATEGORIES, TRANSLATIONS } from '../constants';
import { Article } from '../types';
import { fetchTopHeadlines } from '../services/newsService';
import { NewsCard } from '../components/NewsCard';
import { Loader2 } from 'lucide-react';
import { useApp } from '../context/AppContext';

export const Home: React.FC = () => {
  const { settings } = useApp();
  const t = TRANSLATIONS[settings.language] || TRANSLATIONS['en'];
  const [activeCategory, setActiveCategory] = useState('general');
  const [articles, setArticles] = useState<Article[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadNews = async () => {
      setLoading(true);
      try {
        const data = await fetchTopHeadlines(activeCategory, settings);
        setArticles(data);
      } catch (error) {
        console.error("Failed to fetch news", error);
      } finally {
        setLoading(false);
      }
    };
    loadNews();
  }, [activeCategory, settings]);

  return (
    <div className="space-y-6">
      <div className="overflow-x-auto pb-2 -mx-4 px-4 scrollbar-hide">
        <div className="flex gap-2 w-max">
          {CATEGORIES.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id)}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-all whitespace-nowrap ${
                activeCategory === cat.id
                  ? 'bg-primary text-white shadow-md'
                  : 'bg-white dark:bg-gray-800 text-gray-600 dark:text-gray-300 border border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>
      </div>

      {!loading && articles.length > 0 && (
        <NewsCard article={articles[0]} featured />
      )}

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {loading ? (
          <div className="col-span-full flex flex-col items-center justify-center py-20">
            <Loader2 className="w-10 h-10 animate-spin text-primary mb-4" />
            <p className="text-gray-500 dark:text-gray-400">{t.loading}</p>
          </div>
        ) : (
          articles.slice(1).map((article) => (
            <NewsCard key={article.id} article={article} />
          ))
        )}
      </div>
      
      {!loading && articles.length === 0 && (
        <div className="text-center py-20 text-gray-500">
           {t.noResults}
        </div>
      )}
    </div>
  );
};
