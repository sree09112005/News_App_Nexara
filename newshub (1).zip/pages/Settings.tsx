
import React from 'react';
import { useApp } from '../context/AppContext';
import { Moon, Sun, Bell, Globe, Shield, Database, ChevronRight, Check, Image as ImageIcon, Sparkles } from 'lucide-react';
import { LANGUAGES, TRANSLATIONS } from '../constants';

export const Settings: React.FC = () => {
  const { settings, updateSettings } = useApp();
  const [showLanguageModal, setShowLanguageModal] = React.useState(false);
  const [showImageSourceModal, setShowImageSourceModal] = React.useState(false);
  const [showImageStyleModal, setShowImageStyleModal] = React.useState(false);
  const t = TRANSLATIONS[settings.language] || TRANSLATIONS['en'];

  const toggleTheme = () => {
    updateSettings({ theme: settings.theme === 'light' ? 'dark' : 'light' });
  };

  const currentLangLabel = LANGUAGES.find(l => l.code === settings.language)?.label || 'English';

  const SettingItem = ({ icon: Icon, label, value, onClick, toggle }: any) => (
    <div 
      onClick={onClick}
      className="flex items-center justify-between p-4 bg-white dark:bg-gray-800 rounded-xl border border-gray-100 dark:border-gray-700 cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-750 transition-colors"
    >
      <div className="flex items-center gap-3">
        <div className="p-2 bg-gray-100 dark:bg-gray-700 rounded-lg text-gray-600 dark:text-gray-300">
          <Icon className="w-5 h-5" />
        </div>
        <span className="font-medium text-gray-900 dark:text-white">{label}</span>
      </div>
      {toggle !== undefined ? (
        <div className={`w-12 h-6 rounded-full p-1 transition-colors ${toggle ? 'bg-primary' : 'bg-gray-300 dark:bg-gray-600'}`}>
          <div className={`bg-white w-4 h-4 rounded-full shadow-sm transform transition-transform ${toggle ? 'translate-x-6' : ''}`} />
        </div>
      ) : (
        <div className="flex items-center gap-2 text-gray-500">
          <span className="text-sm">{value}</span>
          <ChevronRight className="w-4 h-4" />
        </div>
      )}
    </div>
  );

  return (
    <div className="space-y-6 relative">
      <h1 className="text-2xl font-bold text-gray-900 dark:text-white">{t.settings}</h1>

      <div className="space-y-4">
        <h2 className="text-sm font-bold text-gray-500 uppercase tracking-wider ml-1">Preferences</h2>
        <SettingItem 
          icon={settings.theme === 'light' ? Sun : Moon}
          label="Dark Mode"
          toggle={settings.theme === 'dark'}
          onClick={toggleTheme}
        />
        <SettingItem 
          icon={Globe}
          label="Language"
          value={currentLangLabel}
          onClick={() => setShowLanguageModal(true)}
        />
      </div>

      <div className="space-y-4">
        <h2 className="text-sm font-bold text-gray-500 uppercase tracking-wider ml-1">Media</h2>
        <SettingItem 
          icon={ImageIcon}
          label={t.imageSource}
          value={settings.imageSource === 'web' ? t.webReferenced : t.aiGenerated}
          onClick={() => setShowImageSourceModal(true)}
        />
        {settings.imageSource === 'ai' && (
          <SettingItem 
            icon={Sparkles}
            label={t.imageStyle}
            value={t[settings.aiImageStyle]}
            onClick={() => setShowImageStyleModal(true)}
          />
        )}
      </div>

      <div className="space-y-4">
        <h2 className="text-sm font-bold text-gray-500 uppercase tracking-wider ml-1">Notifications</h2>
        <SettingItem 
          icon={Bell}
          label="Push Notifications"
          toggle={settings.notifications}
          onClick={() => updateSettings({ notifications: !settings.notifications })}
        />
      </div>

      <div className="text-center pt-8 text-sm text-gray-400">
        <p>NewsHub v1.2.0 (AI Enhanced)</p>
      </div>

      {/* Modals */}
      {showLanguageModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
          <div className="bg-white dark:bg-gray-900 rounded-2xl w-full max-w-sm overflow-hidden shadow-2xl animate-fadeIn">
            <div className="p-4 border-b dark:border-gray-800 flex justify-between items-center">
              <h3 className="font-bold text-lg dark:text-white">Select Language</h3>
              <button onClick={() => setShowLanguageModal(false)} className="text-gray-500">Close</button>
            </div>
            <div className="p-2 max-h-[60vh] overflow-y-auto">
              {LANGUAGES.map((lang) => (
                <button
                  key={lang.code}
                  onClick={() => { updateSettings({ language: lang.code }); setShowLanguageModal(false); }}
                  className={`w-full flex items-center justify-between p-3 rounded-xl ${settings.language === lang.code ? 'bg-primary/10 text-primary' : 'dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800'}`}
                >
                  <span>{lang.label}</span>
                  {settings.language === lang.code && <Check className="w-5 h-5" />}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {showImageSourceModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
          <div className="bg-white dark:bg-gray-900 rounded-2xl w-full max-w-sm overflow-hidden shadow-2xl">
            <div className="p-4 border-b dark:border-gray-800 flex justify-between items-center">
              <h3 className="font-bold text-lg dark:text-white">{t.imageSource}</h3>
              <button onClick={() => setShowImageSourceModal(false)} className="text-gray-500">Close</button>
            </div>
            <div className="p-2">
              <button
                onClick={() => { updateSettings({ imageSource: 'web' }); setShowImageSourceModal(false); }}
                className={`w-full flex items-center justify-between p-4 mb-2 rounded-xl ${settings.imageSource === 'web' ? 'bg-primary/10 text-primary' : 'dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800'}`}
              >
                <span>{t.webReferenced}</span>
                {settings.imageSource === 'web' && <Check className="w-5 h-5" />}
              </button>
              <button
                onClick={() => { updateSettings({ imageSource: 'ai' }); setShowImageSourceModal(false); }}
                className={`w-full flex items-center justify-between p-4 rounded-xl ${settings.imageSource === 'ai' ? 'bg-primary/10 text-primary' : 'dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800'}`}
              >
                <span>{t.aiGenerated}</span>
                {settings.imageSource === 'ai' && <Check className="w-5 h-5" />}
              </button>
            </div>
          </div>
        </div>
      )}

      {showImageStyleModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
          <div className="bg-white dark:bg-gray-900 rounded-2xl w-full max-w-sm overflow-hidden shadow-2xl">
            <div className="p-4 border-b dark:border-gray-800 flex justify-between items-center">
              <h3 className="font-bold text-lg dark:text-white">{t.imageStyle}</h3>
              <button onClick={() => setShowImageStyleModal(false)} className="text-gray-500">Close</button>
            </div>
            <div className="p-2">
              {['photorealistic', 'illustrative', 'abstract'].map((style: any) => (
                <button
                  key={style}
                  onClick={() => { updateSettings({ aiImageStyle: style }); setShowImageStyleModal(false); }}
                  className={`w-full flex items-center justify-between p-4 mb-2 rounded-xl ${settings.aiImageStyle === style ? 'bg-primary/10 text-primary' : 'dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800'}`}
                >
                  <span>{t[style]}</span>
                  {settings.aiImageStyle === style && <Check className="w-5 h-5" />}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
