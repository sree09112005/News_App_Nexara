
import { Article, Category, UserSettings } from "../types";
import { MOCK_NEWS_DELAY } from "../constants";
import { fetchNewsWithGemini } from "./geminiService";

const hasApiKey = !!process.env.API_KEY;
const cache = new Map<string, { data: Article[]; timestamp: number }>();
const CACHE_DURATION = 5 * 60 * 1000;

const generateMockArticles = (category: string, count: number, settings: UserSettings): Article[] => {
  const isHindi = settings.language === 'hi';
  
  const mockThemes: Record<string, string[]> = {
    technology: ["Futuristic computer hardware", "Digital server room", "Modern smartphone"],
    sports: ["Action sports stadium", "Basketball game", "Athletic competition"],
    business: ["Modern skyscraper glass", "Stock market growth", "Professional business meeting"],
    general: ["City skyline at morning", "Modern newspaper", "World map digital"],
    science: ["Deep space galaxy", "Laboratory microscope", "Advanced physics lab"]
  };

  return Array.from({ length: count }).map((_, i) => {
    const title = isHindi 
        ? `${category.toUpperCase()} समाचार: मुख्य कहानी ${i+1}` 
        : `Major ${category.charAt(0).toUpperCase() + category.slice(1)} Update: Global Story ${i+1}`;

    const themes = mockThemes[category] || mockThemes.general;
    const visualDesc = themes[i % themes.length];

    const styleModifier = settings.aiImageStyle === 'photorealistic' 
        ? 'high quality photography'
        : settings.aiImageStyle === 'illustrative'
        ? 'digital illustration'
        : 'abstract art';

    const cleanPrompt = `${styleModifier} ${visualDesc}`.replace(/[^a-zA-Z0-9 ]/g, '');
    const encodedPrompt = encodeURIComponent(cleanPrompt);
    
    const aiImageUrl = `https://image.pollinations.ai/prompt/${encodedPrompt}?width=1080&height=720&nologo=true&seed=${i + 100}`;
    
    return {
      id: `${category}-${Date.now()}-${i}`,
      source: { id: 'mock', name: isHindi ? 'न्यूज़ नेटवर्क' : 'News Network' },
      author: 'Staff Reporter',
      title: title,
      description: isHindi
        ? `यह कहानी ${category} के क्षेत्र में हालिया प्रगति पर केंद्रित है।`
        : `This story explores the latest advancements and major events happening in the world of ${category}. It details the current landscape and future expectations.`,
      url: '#',
      urlToImage: aiImageUrl,
      aiImageUrl: aiImageUrl,
      publishedAt: new Date(Date.now() - (i * 1000 * 60 * 45)).toISOString(),
      content: null,
      category: category as Category
    };
  });
};

export const fetchTopHeadlines = async (category: string = 'general', settings: UserSettings): Promise<Article[]> => {
  const cacheKey = `news-${category}-${settings.language}-${settings.imageSource}-${settings.aiImageStyle}`;
  const cached = cache.get(cacheKey);

  if (cached && (Date.now() - cached.timestamp < CACHE_DURATION)) {
    return cached.data;
  }

  if (hasApiKey) {
    try {
      const realNews = await fetchNewsWithGemini(category, settings.language, settings);
      if (realNews.length > 0) {
        cache.set(cacheKey, { data: realNews, timestamp: Date.now() });
        return realNews;
      }
    } catch (e) {
      console.warn("Falling back to mock", e);
    }
  }

  return new Promise((resolve) => {
    setTimeout(() => {
      const articles = generateMockArticles(category, 15, settings);
      cache.set(cacheKey, { data: articles, timestamp: Date.now() });
      resolve(articles);
    }, MOCK_NEWS_DELAY);
  });
};

export const getRelatedArticles = async (currentArticle: Article): Promise<Article[]> => {
  // Grab other articles from the same category from cache
  const related: Article[] = [];
  for (const entry of cache.values()) {
    const fromSameCat = entry.data.filter(a => a.category === currentArticle.category && a.id !== currentArticle.id);
    related.push(...fromSameCat);
    if (related.length >= 6) break;
  }
  return related.slice(0, 6);
};

export const searchNews = async (query: string, settings: UserSettings): Promise<Article[]> => {
  if (hasApiKey) {
    try {
      const realNews = await fetchNewsWithGemini(query, settings.language, settings);
      if (realNews.length > 0) return realNews;
    } catch (e) {}
  }

  return new Promise((resolve) => {
    setTimeout(() => {
      const articles = generateMockArticles('general', 10, settings).map((a, i) => {
        return { ...a, title: `${query}: ${a.title}` };
      });
      resolve(articles);
    }, MOCK_NEWS_DELAY);
  });
};

export const getArticleById = async (id: string): Promise<Article | undefined> => {
  for (const value of cache.values()) {
    const found = value.data.find(a => a.id === id);
    if (found) return found;
  }
  return undefined;
};
