
import { GoogleGenAI, Type } from "@google/genai";
import { AIResponse, Article, Category, UserSettings } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const getLanguageName = (code: string) => {
  const map: Record<string, string> = {
    'en': 'English', 'hi': 'Hindi', 'bn': 'Bengali', 'te': 'Telugu',
    'mr': 'Marathi', 'ta': 'Tamil', 'gu': 'Gujarati', 'kn': 'Kannada',
    'ml': 'Malayalam', 'pa': 'Punjabi', 'es': 'Spanish', 'fr': 'French',
    'de': 'German', 'zh': 'Chinese'
  };
  return map[code] || 'English';
};

const extractKeywords = (text: string, limit: number = 8): string => {
  if (!text) return '';
  const stopWords = new Set(['the', 'and', 'with', 'from', 'this', 'that', 'they', 'have', 'been', 'will', 'would', 'could', 'should', 'about', 'their', 'there', 'news', 'update', 'breaking']);
  return text
    .toLowerCase()
    .replace(/[^a-zA-Z0-9\s]/gi, ' ')
    .split(/\s+/)
    .filter(word => word.length > 3 && !stopWords.has(word))
    .slice(0, limit)
    .join(' ');
};

export const fetchNewsWithGemini = async (
  category: string, 
  languageCode: string, 
  settings: UserSettings
): Promise<Article[]> => {
  if (!process.env.API_KEY) return [];

  const language = getLanguageName(languageCode);
  const topic = category === 'general' ? 'breaking world news' : `${category} news`;
  const currentDateTime = new Date().toLocaleString();

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Time: ${currentDateTime}. Find exactly 15-20 current, high-impact news articles about "${topic}" in ${language}. 
      Return multiple relevant image URLs for each article if found.
      Ensure the description for each article is comprehensive and engaging (at least 3 sentences).
      Provide a 'visualDescription' for an image generator.
      Output strictly as JSON.`,
      config: { 
        tools: [{ googleSearch: {} }],
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            articles: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  title: { type: Type.STRING },
                  description: { type: Type.STRING },
                  source: { type: Type.STRING },
                  publishedAt: { type: Type.STRING },
                  url: { type: Type.STRING },
                  imageUrl: { type: Type.STRING },
                  additionalImageUrls: { type: Type.ARRAY, items: { type: Type.STRING } },
                  visualDescription: { type: Type.STRING }
                },
                required: ["title", "description", "source", "url", "publishedAt"]
              }
            }
          }
        }
      }
    });

    const data = JSON.parse(response.text || "{}");
    const articlesArray = data.articles || [];
    
    return articlesArray.map((item: any, index: number) => {
      const styleConfig = {
        photorealistic: 'high-end news photography, 8k, realistic, cinematic lighting',
        illustrative: 'clean flat vector illustration, vibrant, modern editorial',
        abstract: 'conceptual abstract digital art, atmospheric textures'
      };

      const styleModifier = styleConfig[settings.aiImageStyle] || styleConfig.photorealistic;
      const titleClean = extractKeywords(item.title, 6);
      const sceneClean = extractKeywords(item.visualDescription || item.description || '', 6);
      
      const prompt = `${styleModifier} showing ${titleClean} ${sceneClean}`.substring(0, 200);
      const encodedPrompt = encodeURIComponent(prompt);
      
      const aiImageUrl = `https://image.pollinations.ai/prompt/${encodedPrompt}?width=1080&height=720&nologo=true&seed=${index + new Date().getHours()}`;

      return {
        id: `gemini-${index}-${Date.now()}`,
        source: { id: null, name: item.source || 'NewsHub' },
        author: null,
        title: item.title,
        description: item.description,
        url: item.url || '#',
        urlToImage: (settings.imageSource === 'web' && item.imageUrl) ? item.imageUrl : aiImageUrl,
        aiImageUrl, 
        additionalImageUrls: item.additionalImageUrls || [],
        publishedAt: item.publishedAt || new Date().toISOString(),
        content: null,
        category: category as Category,
      };
    });
  } catch (error) {
    console.error("Gemini News Fetch Error:", error);
    return [];
  }
};

export const generateNewsSummary = async (content: string, title: string): Promise<AIResponse> => {
  if (!process.env.API_KEY) return { summary: "Error loading summary", keyPoints: [] };
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Summarize this news article titled "${title}". Content: ${content.substring(0, 2500)}`,
    config: { 
      responseMimeType: 'application/json',
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          summary: { type: Type.STRING },
          keyPoints: { type: Type.ARRAY, items: { type: Type.STRING } }
        }
      }
    }
  });
  return JSON.parse(response.text || "{}");
};
