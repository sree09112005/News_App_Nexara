
import React, { useState, useEffect } from 'react';
import { Article } from '../types';
import { Share2, Bookmark, ExternalLink, ImageOff, Calendar, Clock } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { useNavigate } from 'react-router-dom';
import { TRANSLATIONS } from '../constants';

interface NewsCardProps {
  article: Article;
  featured?: boolean;
  minimal?: boolean;
}

export const NewsCard: React.FC<NewsCardProps> = ({ article, featured = false, minimal = false }) => {
  const { isBookmarked, toggleBookmark, settings } = useApp();
  const t = TRANSLATIONS[settings.language] || TRANSLATIONS['en'];
  const navigate = useNavigate();
  const bookmarked = isBookmarked(article.id);
  
  const [imgSource, setImgSource] = useState<string | null>(article.urlToImage);
  const [isAi, setIsAi] = useState(false);
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    setImgSource(article.urlToImage);
    setIsAi(false);
    setFailed(false);
  }, [article.urlToImage]);

  const handleImgError = () => {
    if (!isAi && article.aiImageUrl && imgSource !== article.aiImageUrl) {
      setImgSource(article.aiImageUrl);
      setIsAi(true);
    } else {
      setFailed(true);
    }
  };

  const handleCardClick = () => {
    navigate(`/article/${encodeURIComponent(article.id)}`, { state: { article } });
  };

  const handleBookmark = (e: React.MouseEvent) => {
    e.stopPropagation();
    toggleBookmark(article);
  };

  const readingTime = Math.max(1, Math.ceil((article.description?.length || 100) / 250));

  const getFormattedDateTime = (dateString: string) => {
    if (!dateString) return 'Just now';
    try {
      const date = new Date(dateString);
      return date.toLocaleDateString(undefined, { 
        month: 'short', 
        day: 'numeric', 
        hour: '2-digit', 
        minute: '2-digit' 
      });
    } catch (e) { return 'Recent'; }
  };

  const ImageDisplay = ({ className }: { className: string }) => {
    if (failed || !imgSource) {
      return (
        <div className={`${className} bg-gray-100 dark:bg-gray-800 flex flex-col items-center justify-center text-gray-400 border border-gray-200 dark:border-gray-700`}>
          <div className="p-4 bg-primary/5 rounded-full mb-2">
            <ImageOff className="w-6 h-6 opacity-20 text-primary" />
          </div>
        </div>
      );
    }

    return (
      <div className={`relative ${className} overflow-hidden bg-gray-200 dark:bg-gray-700`}>
        <img 
          src={imgSource} 
          alt={article.title} 
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
          onError={handleImgError}
          loading="lazy"
        />
        
        <div className="absolute bottom-2 left-2 flex flex-wrap gap-1 z-10">
          <div className="bg-primary/90 shadow-lg backdrop-blur-sm text-white text-[8px] font-black uppercase px-2 py-1 rounded-md tracking-wider border border-white/10">
            {article.source.name}
          </div>
          {isAi && (
            <div className="bg-black/40 backdrop-blur-md text-white text-[7px] font-black uppercase px-2 py-1 rounded-md tracking-tighter border border-white/5">
              AI
            </div>
          )}
        </div>
      </div>
    );
  };

  if (minimal) {
    return (
      <div onClick={handleCardClick} className="flex-shrink-0 w-64 bg-white dark:bg-gray-800 rounded-[1.5rem] overflow-hidden shadow-sm border border-gray-100 dark:border-gray-700 cursor-pointer group hover:shadow-lg transition-all">
        <div className="h-32">
          <ImageDisplay className="w-full h-full" />
        </div>
        <div className="p-4">
          <h4 className="text-sm font-bold text-gray-900 dark:text-white line-clamp-2 leading-tight group-hover:text-primary transition-colors">
            {article.title}
          </h4>
        </div>
      </div>
    );
  }

  if (featured) {
    return (
      <div onClick={handleCardClick} className="group relative h-[450px] w-full rounded-[2.5rem] overflow-hidden cursor-pointer shadow-2xl transition-all border border-gray-100 dark:border-gray-800">
        <ImageDisplay className="absolute inset-0 w-full h-full" />
        <div className="absolute inset-0 bg-gradient-to-t from-black/95 via-black/30 to-transparent p-8 md:p-12 flex flex-col justify-end">
          <h2 className="text-white text-3xl md:text-5xl font-black mb-6 line-clamp-3 leading-[1.05] tracking-tight">
            {article.title}
          </h2>
          <div className="flex items-center gap-6 text-gray-300 text-[10px] font-black uppercase tracking-[0.2em]">
            <span className="flex items-center gap-2"><Calendar className="w-4 h-4 text-primary" /> {getFormattedDateTime(article.publishedAt)}</span>
            <span className="flex items-center gap-2"><Clock className="w-4 h-4 text-primary" /> {readingTime} {t.minRead}</span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div onClick={handleCardClick} className="bg-white dark:bg-gray-800 rounded-[2rem] overflow-hidden shadow-sm hover:shadow-2xl transition-all cursor-pointer flex flex-col h-full border border-gray-100 dark:border-gray-700 group">
      <div className="relative h-52 overflow-hidden bg-gray-100 dark:bg-gray-900">
        <ImageDisplay className="w-full h-full" />
        <button onClick={handleBookmark} className={`absolute top-4 right-4 p-2.5 rounded-2xl backdrop-blur-xl transition-all z-20 ${bookmarked ? 'bg-secondary text-white shadow-lg' : 'bg-black/20 text-white hover:bg-black/40'}`}>
          <Bookmark className={`w-4 h-4 ${bookmarked ? 'fill-current' : ''}`} />
        </button>
      </div>
      <div className="p-6 flex flex-col flex-grow">
        <div className="flex items-center justify-between mb-3">
          <span className="text-[10px] font-black text-primary uppercase tracking-widest">{article.category || 'World'}</span>
          <div className="flex items-center gap-2 text-[9px] text-gray-400 font-bold uppercase tracking-wider">
            <span>{getFormattedDateTime(article.publishedAt)}</span>
            <span className="w-1 h-1 bg-gray-300 rounded-full"></span>
            <span>{readingTime} {t.minRead}</span>
          </div>
        </div>
        <h3 className="text-gray-900 dark:text-white font-black text-xl mb-3 line-clamp-2 leading-tight tracking-tight group-hover:text-primary transition-colors">{article.title}</h3>
        <p className="text-gray-500 dark:text-gray-400 text-sm line-clamp-3 mb-6 flex-grow leading-relaxed">{article.description}</p>
        <div className="flex items-center justify-between pt-5 border-t border-gray-50 dark:border-gray-700/50">
          <div className="flex gap-4">
            <Share2 className="w-4 h-4 text-gray-400 hover:text-primary transition-colors" />
            <ExternalLink className="w-4 h-4 text-gray-400 hover:text-primary transition-colors" />
          </div>
          <div className="w-2 h-2 rounded-full bg-primary/30 animate-pulse"></div>
        </div>
      </div>
    </div>
  );
};
