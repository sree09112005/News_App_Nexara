
import React, { useState } from 'react';
import { generateNewsSummary } from '../services/geminiService';
import { AIResponse } from '../types';
import { Sparkles, Loader2, List, FileText } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { TRANSLATIONS } from '../constants';

interface AISummaryProps {
  content: string;
  title: string;
}

export const AISummary: React.FC<AISummaryProps> = ({ content, title }) => {
  const { settings } = useApp();
  const t = TRANSLATIONS[settings.language] || TRANSLATIONS['en'];
  const [summaryData, setSummaryData] = useState<AIResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleGenerate = async () => {
    setLoading(true);
    setError(null);
    try {
      const result = await generateNewsSummary(content, title);
      setSummaryData(result);
    } catch (err) {
      setError("Failed to generate summary. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  if (!summaryData && !loading && !error) {
    return (
      <div className="my-6">
        <button
          onClick={handleGenerate}
          className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-primary to-blue-600 text-white py-3 px-6 rounded-xl font-medium shadow-md hover:shadow-lg transition-all active:scale-95"
        >
          <Sparkles className="w-5 h-5" />
          {t.generateSummary}
        </button>
      </div>
    );
  }

  return (
    <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-100 dark:border-blue-800 rounded-2xl p-6 my-6 shadow-sm transition-all">
      <div className="flex items-center gap-2 mb-4 text-primary dark:text-blue-400 font-bold text-lg">
        <Sparkles className="w-6 h-6" />
        <h2>AI Summary</h2>
      </div>

      {loading && (
        <div className="flex flex-col items-center justify-center py-8 text-gray-500 dark:text-gray-400">
          <Loader2 className="w-8 h-8 animate-spin mb-2 text-primary" />
          <p>{t.analyzing}</p>
        </div>
      )}

      {error && (
        <div className="text-red-500 text-center py-4">
          <p>{error}</p>
          <button onClick={handleGenerate} className="text-primary underline mt-2">Retry</button>
        </div>
      )}

      {summaryData && !loading && (
        <div className="space-y-4 animate-fadeIn">
          <div>
            <div className="flex items-center gap-2 text-gray-700 dark:text-gray-300 font-semibold mb-2">
              <FileText className="w-4 h-4" />
              <h3>{t.overview}</h3>
            </div>
            <p className="text-gray-600 dark:text-gray-300 leading-relaxed text-sm md:text-base">
              {summaryData.summary}
            </p>
          </div>
          
          <div className="bg-white dark:bg-gray-800 p-4 rounded-xl">
            <div className="flex items-center gap-2 text-gray-700 dark:text-gray-300 font-semibold mb-3">
              <List className="w-4 h-4" />
              <h3>{t.keyTakeaways}</h3>
            </div>
            <ul className="space-y-2">
              {summaryData.keyPoints.map((point, idx) => (
                <li key={idx} className="flex gap-2 text-gray-600 dark:text-gray-300 text-sm md:text-base">
                  <span className="text-secondary font-bold">•</span>
                  {point}
                </li>
              ))}
            </ul>
          </div>
        </div>
      )}
    </div>
  );
};
