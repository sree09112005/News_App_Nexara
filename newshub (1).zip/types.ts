
export enum Category {
  General = 'general',
  Technology = 'technology',
  Sports = 'sports',
  Business = 'business',
  Entertainment = 'entertainment',
  Health = 'health',
  Science = 'science',
  Politics = 'politics'
}

export type ImageSource = 'web' | 'ai';
export type AIImageStyle = 'photorealistic' | 'illustrative' | 'abstract';

export interface Article {
  id: string;
  source: {
    id: string | null;
    name: string;
  };
  author: string | null;
  title: string;
  description: string | null;
  url: string;
  urlToImage: string | null;
  aiImageUrl?: string; 
  additionalImageUrls?: string[]; // Multiple web-found images
  publishedAt: string;
  content: string | null;
  category?: Category;
  groundingUrls?: { title: string; uri: string }[];
}

export interface UserSettings {
  theme: 'light' | 'dark';
  language: string;
  notifications: boolean;
  dataSaver: boolean;
  imageSource: ImageSource;
  aiImageStyle: AIImageStyle;
}

export interface AIResponse {
  summary: string;
  keyPoints: string[];
}
